# Trace CLI

Living documentation and test traceability for software projects.

Trace connects Markdown feature documents and their behavior rules to source
paths, tests, test results, and coverage. It reports undocumented changes,
unlinked tests, and coverage gaps so documentation stays trustworthy.

**Status:** v0.4.1 is the opinionated engine: Markdown feature documents with
rule headings, JUnit XML, lcov, and local `trace verify`. The v0.1–v0.3 specs
remain historical; current behavior is in
[`docs/specs/v0.4-spec.md`](docs/specs/v0.4-spec.md).

**Package:** `trace-docs` · **bins:** `trace`, `trace-docs` ·
local install is supported; publishing is optional.

## Commands

| Command | Purpose |
| --- | --- |
| `trace init` | Create the config, feature directory, and monthly decision ledger. |
| `trace create feature "Title"` | Generate a feature document from the template. |
| `trace list` | List documented features. |
| `trace context <ID>` | Show everything Trace knows about one feature or rule. |
| `trace check` | Validate documents, ids, rules, paths, ownership, links, evidence, and coverage. |
| `trace changes` | Report features affected by the current Git diff. |
| `trace verify` | Local gate: check the docs and require changed features to update their docs. |

Every command supports `--json` with a versioned envelope and stable exit codes.

## Principles

- **Implemented behavior only.** A Trace Docs rule describes what the product
  does today and has a proving test. Deferred work, non-goals, plans, ADRs, and
  implementation notes live outside Trace Docs.
- **One document, several rules.** A feature document uses headings such as
  `### [CHAT-INPUT-001] A pending response blocks a second send`.
- **Tests declare their rule.** Documents never list tests. A test carrying
  `[CHAT-INPUT-001]` is linked; JUnit XML proves pass/fail.
- **One opinionated stack.** Markdown documents, JUnit XML results, and lcov
  coverage. Unsupported formats fail clearly.
- **Owned is not the same as related.** `paths` are exclusive for coverage;
  `links` are many-to-many for impact.
- **Local first.** `trace verify` is the normal gate; CI is optional.
- **Read-only.** No network, no database, no test execution. Only `init` and
  `create` write to the target project.

## Documentation

- [Scope — implemented behavior only](docs/scope.md)
- [Architecture](docs/architecture.md)
- [Specifications](docs/specs/README.md) —
  [v0.1](docs/specs/v0.1-spec.md), [v0.2](docs/specs/v0.2-spec.md),
  [v0.3](docs/specs/v0.3-spec.md), [v0.4](docs/specs/v0.4-spec.md),
  [edge behavior](docs/specs/edge-behavior.md)
- [Command reference](docs/reference/commands.md)
- [JSON envelope schema](docs/reference/envelope.schema.json)
- [v0.1 plan](docs/plans/v0.1-plan.md)
- [Decision records](docs/decisions/README.md)
- [Changelog](CHANGELOG.md)

## License

MIT © 2026 Renan Silva
